from django.apps import AppConfig


class ListaappConfig(AppConfig):
    name = 'ListaApp'
